<?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["file"])) {
    move_uploaded_file($_FILES["file"]["tmp_name"], "uploads/" . basename($_FILES["file"]["name"]));
    echo "Upload selesai! <a href='flag.txt'>Baca flag</a>";
}
?>
<form method="POST" enctype="multipart/form-data"><input type="file" name="file"><button type="submit">Upload</button></form>