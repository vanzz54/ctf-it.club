<?php $conn = new mysqli("localhost", "user", "pass", "ctf_db");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST["username"]; $pass = $_POST["password"];
    $query = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        session_start(); $_SESSION["user"] = $result->fetch_assoc()["username"];
        echo "<p style='color:green'>Login berhasil! <a href='upload.php'>Upload file</a></p>";
    } else { echo "<p style='color:red'>Login gagal!</p>"; }
}
?>