<?php $conn = new mysqli("localhost", "user", "pass", "ctf_db");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"]; $user = $_POST["username"]; $pass = $_POST["password"];
    $query = "INSERT INTO users (name, username, password) VALUES ('$name', '$user', '$pass')";
    $conn->query($query);
    echo "Register berhasil! <a href='login.php'>Login</a>";
}
?>