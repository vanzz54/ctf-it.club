<?php
$conn = new mysqli("localhost", "user", "pass", "ctf_db");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST["username"];
    $pass = $_POST["password"];
    // CELAH: SQL Injection
    $query = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        echo "<p style='color:green'>Login berhasil!</p>";
        echo "<a href='admin_panel.php'>Klik di sini untuk akses panel admin</a>";
    } else {
        echo "<p style='color:red'>Login gagal!</p>";
    }
}
?>