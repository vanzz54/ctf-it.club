<?php
$users = ["admin" => md5("admin123"), "user1" => md5("password1")];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST["username"];
    $pass = $_POST["password"];
    $hash = md5($pass);
    if (isset($users[$user]) && $users[$user] == $hash) {
        session_id($_POST["session_id"]);
        session_start();
        if ($user == "admin") {
            $_SESSION["admin"] = true;
            echo "<p style='color:green'>Welcome, admin!</p><a href='data.php'>Lihat data sensitif</a>";
        } else {
            echo "<p style='color:green'>Login berhasil!</p>";
        }
    } else {
        echo "<p style='color:red'>Login gagal!</p>";
    }
}
?>