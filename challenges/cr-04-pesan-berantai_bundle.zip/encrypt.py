#!/usr/bin/env python3
from Crypto.Util.number import getPrime, bytes_to_long
from secret import flag

print("[*] Men-generate 3 pasang kunci RSA untuk 3 cabang berbeda...")

e = 3
m = bytes_to_long(flag)

n_list = []
c_list = []

for i in range(3):
    p = getPrime(1024)
    q = getPrime(1024)
    n = p * q
    c = pow(m, e, n)
    
    n_list.append(n)
    c_list.append(c)

with open("output.txt", "w") as f:
    f.write(f"e = {e}\n\n")
    for i in range(3):
        f.write(f"n{i+1} = {n_list[i]}\n")
        f.write(f"c{i+1} = {c_list[i]}\n\n")

print("[+] Broadcast enkripsi selesai. File output.txt berhasil dibuat!")